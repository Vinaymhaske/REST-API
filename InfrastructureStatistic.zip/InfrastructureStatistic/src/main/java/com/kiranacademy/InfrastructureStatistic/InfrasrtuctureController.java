package com.kiranacademy.InfrastructureStatistic;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InfrasrtuctureController {
	
	@Value("${bridgecost111111}")
	int bridgecost;
	
	@Autowired
	X xx= null;
	
	@Autowired
	InfrastructureService infrastructureService = null;
	
	
	@GetMapping ("checkobjectcreation")
	public void leanIOC() {
		System.out.println("bridgecost>>"+bridgecost);
		xx.m2();
		
	}

	@GetMapping("bridgescount" )
	int noofBridgesInIndia() {
		return 7856;
	}
	
	@PostMapping("addbridgeinfo")
	public void addBridge(@RequestBody Bridge bridge) {
		System.out.println("bridge info..."+bridge);
		
	}
	
	
	
	
	
	@RequestMapping("bridgeinfo" )
	Bridge fetchBridgeInfo() {
		Bridge bridge=new Bridge("Pune",11,"50mtr","500mtr");
		return bridge;
	}
	@RequestMapping("bridgesinfo" )
	ArrayList<Bridge> fetchBridgesInfo() {
		
		ArrayList<Bridge> listBridges = infrastructureService.fetchBridgesInfo();
		return listBridges;
		
	}
	
	
 @RequestMapping("bridgenamebycity/{cityname}" )
	
	ArrayList<String> nameofBridgesInCity(@PathVariable String cityname) {
		System.out.println("I am in nameOfBridgesinCity"+cityname);
		
		ArrayList<String>listBridges=new ArrayList<String>();
		if(cityname.equals("pune")) {
		listBridges.add("rajaram bridge");
		listBridges.add("z bridge");
		listBridges.add("warje bridge");
		listBridges.add("nawale bridge");
		}else {
			listBridges.add("rajaram bridge11");
			listBridges.add("z bridge22");
			listBridges.add("warje bridge33");
			listBridges.add("nawale bridge44");
		}
		
		return listBridges;

	
	}
}
	
