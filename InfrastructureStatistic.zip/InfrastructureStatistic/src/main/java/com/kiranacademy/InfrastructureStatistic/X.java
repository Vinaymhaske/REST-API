package com.kiranacademy.InfrastructureStatistic;

import org.springframework.stereotype.Component;

@Component
public class X {
	X(){
		System.err.println("i am in constructer");
	}
void m2() {
	System.err.println("X---i am in m2");
}
}
