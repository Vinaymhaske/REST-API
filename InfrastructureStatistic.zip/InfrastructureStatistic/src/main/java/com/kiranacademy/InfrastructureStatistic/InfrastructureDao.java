package com.kiranacademy.InfrastructureStatistic;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import org.springframework.stereotype.Component;

@Component
public class InfrastructureDao {

	public ArrayList<Bridge> fetchBridgesInfo(){
		ArrayList<Bridge>alBridges=new ArrayList<Bridge>();
		try {
		
	System.out.println(1);
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println(2);
	Connection connection=DriverManager.getConnection("jdbc:mysql:3306/test","root","root");
	System.out.println(3);
	String sql = "select*from bridge";
	System.out.println(4);
	Statement statement=(Statement) connection.createStatement();
	System.out.println(5);
	ResultSet resultSet=((java.sql.Statement) statement).executeQuery(sql);
	while(resultSet.next()) {
		int bridgeNumber= resultSet.getInt(1);
		String bridgeCity= resultSet.getString(2);
		String bridgeLength= resultSet.getString(3);
		String bridgeWidth= resultSet.getString(4);
		Bridge bridge=new Bridge(bridgeCity,bridgeNumber,bridgeLength,bridgeWidth);
		alBridges.add(bridge);
		
	}	
		}catch (Exception e) {
		e.printStackTrace();
	}
	
		return alBridges;
	}
}
