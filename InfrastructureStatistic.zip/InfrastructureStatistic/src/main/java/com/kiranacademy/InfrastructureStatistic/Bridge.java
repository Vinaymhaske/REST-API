package com.kiranacademy.InfrastructureStatistic;

import org.springframework.stereotype.Component;

@Component
public class Bridge {
private String bridgeCity;
private int bridgenuber;
private String bridgeLength;
private String bridgeWidth;


public Bridge() {
	super();
	
}


public Bridge(String bridgeCity, int bridgenuber, String bridgeLength, String bridgeWidth) {
	super();
	this.bridgeCity = bridgeCity;
	this.bridgenuber = bridgenuber;
	this.bridgeLength = bridgeLength;
	this.bridgeWidth = bridgeWidth;
}
 

public String getBridgeCity() {
	return bridgeCity;
}
public void setBridgeCity(String bridgeCity) {
	this.bridgeCity = bridgeCity;
}
public int getBridgenuber() {
	return bridgenuber;
}
public void setBridgenuber(int bridgenuber) {
	this.bridgenuber = bridgenuber;
}
public String getBridgeLength() {
	return bridgeLength;
}
public void setBridgeLength(String bridgeLength) {
	this.bridgeLength = bridgeLength;
}
public String getBridgeWidth() {
	return bridgeWidth;
}
public void setBridgeWidth(String bridgeWidth) {
	this.bridgeWidth = bridgeWidth;
}
@Override
public String toString() {
	return "Bridge [bridgeCity=" + bridgeCity + ", bridgenuber=" + bridgenuber + ", bridgeLength=" + bridgeLength
			+ ", bridgeWidth=" + bridgeWidth + "]";
}

}

	


